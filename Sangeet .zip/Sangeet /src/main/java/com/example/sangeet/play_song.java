package com.example.sangeet;

import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.util.ArrayList;

public class play_song extends AppCompatActivity {

    TextView textView;
    ImageView play, next, prev;
    ArrayList<String> songs;
    MediaPlayer mediaPlayer;
    int position;
    SeekBar seekBar;
    Thread updateSeek;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play_song);

        textView = findViewById(R.id.textView);
        play = findViewById(R.id.play);
        next = findViewById(R.id.next);
        prev = findViewById(R.id.prev);
        seekBar = findViewById(R.id.seekBar);

        Intent intent = getIntent();
        songs = intent.getStringArrayListExtra("songsList");
        position = intent.getIntExtra("position", 0);


        playSong(position);
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {}

            @Override public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                if (mediaPlayer != null) {
                    mediaPlayer.seekTo(seekBar.getProgress());
                }
            }
        });

        updateSeek = new Thread(() -> {
            try {
                while (mediaPlayer != null) {
                    if (mediaPlayer.isPlaying()) {
                        int currentPos = mediaPlayer.getCurrentPosition();
                        runOnUiThread(() -> seekBar.setProgress(currentPos));
                        Thread.sleep(800);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
        updateSeek.start();

        play.setOnClickListener(v -> {
            if (mediaPlayer.isPlaying()) {
                play.setImageResource(R.drawable.playy);
                mediaPlayer.pause();
            } else {
                play.setImageResource(R.drawable.pause);
                mediaPlayer.start();
            }
        });

        // Previous Button
        prev.setOnClickListener(v -> {
            if (mediaPlayer != null) {
                mediaPlayer.stop();
                mediaPlayer.release();
            }
            if (position != 0) {
                position--;
            } else {
                position = songs.size() - 1;
            }
            playSong(position);
        });

        // Next Button
        next.setOnClickListener(v -> {
            if (mediaPlayer != null) {
                mediaPlayer.stop();
                mediaPlayer.release();
            }
            if (position != songs.size() - 1) {
                position++;
            } else {
                position = 0;
            }
            playSong(position);
        });
    }

    private void playSong(int pos) {
        Uri uri = Uri.parse(songs.get(pos));
        mediaPlayer = MediaPlayer.create(this, uri);
        mediaPlayer.start();

        seekBar.setMax(mediaPlayer.getDuration());

        File file = new File(songs.get(pos));
        textView.setText(file.getName());

        play.setImageResource(R.drawable.pause);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null;
        }
        if (updateSeek != null) {
            updateSeek.interrupt();
        }
    }
}