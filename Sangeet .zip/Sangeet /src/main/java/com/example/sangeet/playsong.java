package com.example.sangeet;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class playsong extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play_song);

    }
}