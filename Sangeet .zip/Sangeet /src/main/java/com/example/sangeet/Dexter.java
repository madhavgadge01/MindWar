package com.example.sangeet;

public class Dexter {
    public static Object withContext(MainActivity mainActivity) {
        return null;
    }
}
